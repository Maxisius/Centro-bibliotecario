import java.time.LocalDate;

public class Prestamo {
    private static final String ROJO = "\u001B[31m";
    private static final String AMARILLO = "\u001B[33m";
    private static final String VERDE = "\u001B[32m";
    private static final String RESET = "\u001B[0m";

    private Libro libro;
    private Usuario usuario;
    private LocalDate fechaPrestamo;
    private String estado;

    public Prestamo(Libro libro, Usuario usuario) {
        this.libro = libro;
        this.usuario = usuario;
        this.fechaPrestamo = LocalDate.now();
        this.estado = "Activo";
    }

    public Libro getLibro() { return libro; }
    public Usuario getUsuario() { return usuario; }
    public LocalDate getFechaPrestamo() { return fechaPrestamo; }
    public String getEstado() { return estado; }

    public void registrarPrestamo() {
        libro.setDisponible(false);
        estado = "Activo";
        System.out.println(VERDE + "Prestamo registrado: " + libro.getTitulo()
                + " -> " + usuario.getNombre() + RESET);
    }

    public void finalizarPrestamo() {
        libro.setDisponible(true);
        estado = "Finalizado";
        System.out.println(VERDE + "Prestamo finalizado: " + libro.getTitulo() + RESET);
    }

    public void mostrarInformacion() {
        System.out.println("Libro: " + libro.getTitulo()
                + " | Usuario: " + usuario.getNombre()
                + " | Fecha: " + ROJO + fechaPrestamo + RESET
                + " | Estado: " + AMARILLO + estado + RESET);
    }
}
