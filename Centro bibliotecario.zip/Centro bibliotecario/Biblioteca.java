import java.util.ArrayList;

public class Biblioteca {
    private ArrayList<Libro> libros = new ArrayList<>();
    private ArrayList<Usuario> usuarios = new ArrayList<>();
    private ArrayList<Prestamo> prestamos = new ArrayList<>();

    public void registrarLibro(Libro libro) {
        libros.add(libro);
        System.out.println("Libro registrado correctamente.");
    }

    public void registrarUsuario(Usuario usuario) {
        usuarios.add(usuario);
        System.out.println("Usuario registrado correctamente.");
    }

    public Libro buscarLibro(String codigo) {
        for (Libro l : libros) {
            if (l.getCodigo().equals(codigo)) return l;
        }
        return null;
    }

    public Usuario buscarUsuario(String id) {
        for (Usuario u : usuarios) {
            if (u.getIdentificacion().equals(id)) return u;
        }
        return null;
    }

    public void mostrarLibros() {
        if (libros.isEmpty()) {
            System.out.println("No hay libros registrados.");
            return;
        }
        for (Libro l : libros) l.mostrarInformacion();
    }

    public void prestarLibro(String codigo, String idUsuario) {
        Libro libro = buscarLibro(codigo);
        Usuario usuario = buscarUsuario(idUsuario);

        if (libro == null) {
            System.out.println("El libro no existe.");
        } else if (usuario == null) {
            System.out.println("El usuario no existe.");
        } else if (!libro.isDisponible()) {
            System.out.println("El libro ya se encuentra prestado.");
        } else {
            Prestamo p = new Prestamo(libro, usuario);
            p.registrarPrestamo();
            prestamos.add(p);
        }
    }

    public void devolverLibro(String codigo) {
        for (Prestamo p : prestamos) {
            if (p.getLibro().getCodigo().equals(codigo) && p.getEstado().equals("Activo")) {
                p.finalizarPrestamo();
                return;
            }
        }
        System.out.println("No hay un prestamo activo para ese libro.");
    }

    public void consultarDisponibilidad(String codigo) {
        Libro libro = buscarLibro(codigo);
        if (libro == null) {
            System.out.println("El libro no existe.");
        } else if (libro.isDisponible()) {
            System.out.println("El libro esta disponible.");
        } else {
            System.out.println("El libro esta prestado.");
        }
    }

    public void mostrarPrestamos() {
        if (prestamos.isEmpty()) {
            System.out.println("No hay prestamos registrados.");
            return;
        }
        for (Prestamo p : prestamos) p.mostrarInformacion();
    }
}
