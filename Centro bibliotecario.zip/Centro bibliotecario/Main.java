import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Biblioteca biblioteca = new Biblioteca();
        int opcion;

        do {
            System.out.println("\n===== MENU BIBLIOTECA =====");
            System.out.println("1. Registrar libro");
            System.out.println("2. Registrar usuario");
            System.out.println("3. Consultar libros");
            System.out.println("4. Prestar libro");
            System.out.println("5. Devolver libro");
            System.out.println("6. Consultar disponibilidad de un libro");
            System.out.println("7. Ver prestamos");
            System.out.println("0. Salir");
            System.out.print("Elija una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Codigo: ");
                    String codigo = sc.nextLine();
                    System.out.print("Titulo: ");
                    String titulo = sc.nextLine();
                    System.out.print("Autor: ");
                    String autor = sc.nextLine();
                    biblioteca.registrarLibro(new Libro(codigo, titulo, autor));
                    break;
                case 2:
                    System.out.print("Identificacion: ");
                    String id = sc.nextLine();
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Correo: ");
                    String correo = sc.nextLine();
                    biblioteca.registrarUsuario(new Usuario(id, nombre, correo));
                    break;
                case 3:
                    biblioteca.mostrarLibros();
                    break;
                case 4:
                    System.out.print("Codigo del libro: ");
                    String cod = sc.nextLine();
                    System.out.print("Identificacion del usuario: ");
                    String idUsu = sc.nextLine();
                    biblioteca.prestarLibro(cod, idUsu);
                    break;
                case 5:
                    System.out.print("Codigo del libro a devolver: ");
                    biblioteca.devolverLibro(sc.nextLine());
                    break;
                case 6:
                    System.out.print("Codigo del libro: ");
                    biblioteca.consultarDisponibilidad(sc.nextLine());
                    break;
                case 7:
                    biblioteca.mostrarPrestamos();
                    break;
                case 0:
                    System.out.println("Hasta pronto.");
                    break;
                default:
                    System.out.println("Opcion no valida.");
            }
        } while (opcion != 0);

        sc.close();
    }
}
